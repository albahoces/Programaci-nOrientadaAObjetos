
import civitas.Casilla;
import civitas.CivitasJuego;
import civitas.Dado;
import civitas.Diario;
import civitas.OperacionInmobiliaria;
import civitas.Tablero;
import controladorCivitas.Controlador;
import java.util.ArrayList;
import vistaTextualCivitas.VistaTextual;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author albah
 */
public class JuegoTexto {
    public static void main(String[] args){
        
        //Depuracion Practica 1
        /*
        for(int i = 0; i<100; i++){
            System.out.print(Dado.getInstance().quienEmpieza(4));
        }
        
        Dado.getInstance().setDebug(true);
        System.out.print("\n"+Dado.getInstance().tirar());
        Dado.getInstance().setDebug(false);
        System.out.print("\n"+Dado.getInstance().tirar());
        System.out.print("\n"+Dado.getInstance().tirar());
        System.out.print("\n"+Dado.getInstance().tirar());
        
        System.out.print("\nUltimo res: "+Dado.getInstance().getUltimoResultado());
        
        System.out.print("\n"+OperacionInmobiliaria.CONSTRUIR_CASA);
        */
        Tablero tablero = new Tablero();
        tablero.añadeCasilla(new Casilla("Calle 1", 100,200,300));
        tablero.añadeCasilla(new Casilla("Calle 2", 100,200,300));
        tablero.añadeCasilla(new Casilla("Calle 3", 100,200,300));
        tablero.añadeCasilla(new Casilla("Calle 4", 100,200,300));
        /*
        System.out.print("\n"+tablero.getCasilla(0));
        System.out.print("\n"+tablero.getCasilla(2));
        
        Diario.getInstance().ocurreEvento("Hola");
        Diario.getInstance().ocurreEvento("Chao");
        ArrayList<String> eventos = Diario.getInstance().getEventos();
        for(String evento : eventos){
            System.out.print("\n"+evento);
        }
        
        int pos = 0;
        for(int i=0; i<10; i++){
            pos = tablero.nuevaPosicion(pos, Dado.getInstance().tirar());
            System.out.print("\n"+pos);
        }
        
       
        for(int i =0; i<5; i++){
            System.out.print("\n"+tablero.getCasilla(i).toString());
        }
        */
        
        
        //Depuracion practica 3
        ArrayList<String> nombresJug = new ArrayList<String>();
        nombresJug.add("Alba");
        nombresJug.add("Pablo");
        nombresJug.add("Carmen");
        nombresJug.add("Odie");
        
        CivitasJuego civitas = new CivitasJuego(nombresJug, false);
        VistaTextual vista = new VistaTextual(civitas);
        //Controlador controlador = new Controlador(civitas, vista);
        
        //controlador.juega();
        
        
    }
}
