/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author albah
 */
public class CivitasJuego {
    private int indiceJugadorActual;
    private Tablero tablero;
    private MazoSorpresa mazo;
    private ArrayList<Jugador> jugadores = new ArrayList<Jugador>();
    private EstadoJuego estado;
    private GestorEstados gestor;
    
    public CivitasJuego(ArrayList<String> nombres, boolean debug){
        for(int i=0; i<nombres.size();i++){
            Jugador nuevo = new Jugador(nombres.get(i));
            jugadores.add(nuevo);
        }
        gestor = new GestorEstados();
        estado = gestor.estadoInicial();
        Dado.getInstance().setDebug(debug);
        indiceJugadorActual = Dado.getInstance().quienEmpieza(4);
        mazo = new MazoSorpresa(debug);
        tablero = new Tablero();
        this.inicializaTablero(mazo);
        this.inicializaMazoSorpresa();
        
    }
    
    void inicializaTablero(MazoSorpresa mazo){ //Salida, 14 calle, 4 sorpresa, parking
        //La de salida ya se crea en el constructor
        tablero.añadeCasilla(new CasillaCalle("Calle periquito",300,80,400));
        tablero.añadeCasilla(new CasillaSorpresa("Sorpresa", mazo));
        tablero.añadeCasilla(new CasillaCalle("Calle filipinos", 1000, 200, 600));
        tablero.añadeCasilla(new CasillaCalle("Calle aguila", 200, 600, 700));
        tablero.añadeCasilla(new CasillaCalle("Calle buñuelo",400, 50,100));
        tablero.añadeCasilla(new CasillaCalle("Calle culipato", 500,300,400));
        tablero.añadeCasilla(new CasillaSorpresa("Sorpresa", mazo));
        tablero.añadeCasilla(new Casilla("Calle policia", 700,300,100));
        tablero.añadeCasilla(new CasillaCalle("Calle siberia",800,400,100));
        tablero.añadeCasilla(new CasillaCalle("Calle mochuelo", 500, 800, 300));
        tablero.añadeCasilla(new CasillaCalle("Calle federico", 200,700,200));
        tablero.añadeCasilla(new CasillaCalle("Calle samora",100,100,100));
        tablero.añadeCasilla(new CasillaCalle("Calle Garcia Lorca",300,200,100));
        tablero.añadeCasilla(new CasillaSorpresa("Sorpresa", mazo));
        tablero.añadeCasilla(new CasillaSorpresa("Sorpresa", mazo));
        tablero.añadeCasilla(new CasillaCalle("Calle mostacho",600,350,490));
        tablero.añadeCasilla(new CasillaCalle("Calle periodistas",400,300,200));
        tablero.añadeCasilla(new CasillaCalle("Calle gazpacho",100,700,650));
        tablero.añadeCasilla(new Casilla("Parking"));
    }
    
    void inicializaMazoSorpresa(){ //PAGARCOBRAR 3 positivas, 3 negativas, PORCASAHOTEL 2 posi 2 neg
        
        mazo.alMazo(new SorpresaPagarCobrar("Has roto el banco de el parque!! Tienes que pagarlo!!",-1000));
        mazo.alMazo(new SorpresaPagarCobrar("Pagas impuesto", -500));
        mazo.alMazo(new SorpresaPagarCobrar("Te toca abonar dinero al ayuntamiento",-400));
        mazo.alMazo(new SorpresaPagarCobrar("Has tenido suerte, te has encontrado un billete en el suelo", 500));
        mazo.alMazo(new SorpresaPagarCobrar("Enhorabuena te ha tocado la loteria",1000));
        mazo.alMazo(new SorpresaPagarCobrar("Has tenido suerte, tu primo de cuenta te manda dinero", 300));
        
        mazo.alMazo(new SorpresaPorCasaHotel("Enhorabuena, recibes 400 euros por casa casa y hotel",400));
        mazo.alMazo(new SorpresaPorCasaHotel("Recibes 30 euros por cada hotel", 30));
        mazo.alMazo(new SorpresaPorCasaHotel("Tu hotel se ha derrumbado necesitas hacer obras", -500));
        mazo.alMazo(new SorpresaPorCasaHotel("Tu casa se ha derrumbado necesitas hacer obras", -1000));
        
        mazo.alMazo(new SorpresaConvertirme("Te conviertes a jugador Especulador",0)); //El valor no se cual es
    }

    public int getIndiceJugadorActual() {
        return indiceJugadorActual;
    }

    public Tablero getTablero() {
        return tablero;
    }

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }
    
    public Jugador getJugadorActual(){
        return jugadores.get(indiceJugadorActual);
    }
    
    private void pasarTurno(){
        if(indiceJugadorActual>=3)
            indiceJugadorActual = 0;
        else
            indiceJugadorActual++;
    }
    
    public void siguientePasoCompletado(OperacionJuego operacion){
        estado = gestor.siguienteEstado(getJugadorActual(), estado, operacion);
    }
    
    public OperacionJuego siguientePaso(){
        Jugador jugadorActual = getJugadorActual();
        OperacionJuego operacion = gestor.siguienteOperacion(jugadorActual, estado);
        switch(operacion){
            case PASAR_TURNO:
                pasarTurno();
                this.siguientePasoCompletado(operacion);
                break;
            case AVANZAR:
                avanzaJugador();
                this.siguientePasoCompletado(operacion);
                break;
        }
        return operacion;
    }
    
    
    public boolean cosntruirCasa(int ip){
        getJugadorActual().construirCasa(ip);
        return true;
    }
    
    public boolean cosntruirHotel(int ip){
        getJugadorActual().construirHotel(ip);
        return true;
    }

    
    
    public boolean finalDelJuego(){
        for(int i=0; i<jugadores.size();i++){
            if(jugadores.get(i).enBancaRota()) 
                return true;
        }
        return false;
    }
    
    public ArrayList<Jugador> ranking(){ //Le he cambiado la visibilidad a publica para poder usarlo fuera de su paquete
        ArrayList<Jugador> jugadoresOrdenados = jugadores;
        Collections.sort(jugadoresOrdenados);
        return jugadoresOrdenados;
    }
    
    public String toStringRanking(){
        ArrayList<Jugador> ranking = ranking();
        String rank = "Ranking\n";
        int cont = 1;
        for(Jugador j : ranking){
            rank = "Jugador "+cont+" "+j.toString()+"\n";
            cont++;
        }
        return rank;
    }
    
    private void contabilizarPasosPorSalida(Jugador jugadorActual){
        
        if(tablero.computarPasoPorSalida()) 
            jugadorActual.pasaPorSalida();
    }
    
    private void avanzaJugador(){
        Jugador jugadorActual = getJugadorActual();
        int posicionActual = jugadorActual.getCasillaActual();
        int tirada = Dado.getInstance().tirar();
        int posicionNueva = tablero.nuevaPosicion(posicionActual, tirada);
        Casilla casilla = tablero.getCasilla(posicionNueva);
        contabilizarPasosPorSalida(jugadorActual); //No se le pasa ningun argumento
        jugadorActual.moverACasilla(posicionNueva);
        casilla.recibeJugador(indiceJugadorActual, jugadores);
    }
    
    public boolean comprar(){
        boolean res = false;
        Jugador jugadorActual = getJugadorActual();
        int numCasillaActual = jugadorActual.getCasillaActual();
        Casilla casilla = tablero.getCasilla(numCasillaActual);
        res = jugadorActual.comprar((CasillaCalle)casilla);
        return res;
    }
}
