/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author albah
 */
public class JugadorEspeculador extends Jugador {
    
    private static final int FACTORESPECULADOR = 2;
    
    protected JugadorEspeculador(Jugador j){
        super(j);
    }
    
    @Override
    public String toString(){
        String texto = super.toString() +" Y soy un jugador especulador";
        return texto;
    }
    
    @Override
    boolean paga(float cantidad){
        return modificarSaldo((cantidad/FACTORESPECULADOR)*(-1));    
    }
    
    //No me deja redefinir el metodo
    public static int getCasasMax(){
        return Jugador.getCasasMax()*FACTORESPECULADOR;
    }
    
    public static int getHotelesMax(){
        return Jugador.getHotelesMax()*FACTORESPECULADOR;
    }
    
}
