/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class Jugador implements Comparable<Jugador> {

    protected static int CasasMax = 4;
    protected static int CasasPorHotel = 4;
    private int casillaActual;
    protected static int HotelesMax = 4;
    private String nombre;
    protected static float PasoPorSalida = 1000;
    private boolean puedeComprar;
    private float saldo;
    private static float SaldoInicial = 7500;
    private ArrayList<CasillaCalle> propiedades;
    
    public Jugador(String nombre){
        this.nombre = nombre;
        casillaActual = 0;
        puedeComprar = false;
        saldo = SaldoInicial;
        propiedades = new ArrayList<CasillaCalle>();
    }
    
    Jugador(Jugador otro){ //constructor de copia jugador especulador
        casillaActual = otro.casillaActual;
        nombre = otro.nombre;
        puedeComprar = otro.puedeComprar;
        saldo = otro.saldo;
        propiedades = new ArrayList<CasillaCalle>();
        for(CasillaCalle c :  otro.propiedades){
            propiedades.add(c);
        }
    }
    
    public JugadorEspeculador convertir(){
        JugadorEspeculador jugador = new JugadorEspeculador(this);
        return jugador;
    }
    
    public boolean isEspeculador(){ //Metodo que he creado para saber si el jugador es especulador
        if(this instanceof JugadorEspeculador) return true;
        return false;
    }
    
    @Override
    public String toString(){
        String estado = "Nombre jugador: "+nombre.toString()+"\nCasilla Actual: "+casillaActual+"\nSaldo: "+saldo;
        return estado;
    }
  
    
    private boolean existeLaPropiedad(int ip){
        return propiedades.size() >= ip;
    }
    
    boolean puedeComprarCasilla(){
        puedeComprar = true;
        return puedeComprar;
    }
    
    boolean modificarSaldo(float cantidad){
        saldo += cantidad;
        Diario.getInstance().ocurreEvento("Saldo modificado");
        return true;
    }
    
    boolean paga(float cantidad){
        return modificarSaldo(cantidad*(-1));    
    }
    
    boolean pagaAlquiler(float cantidad){
        return paga(cantidad);
    }
    
    boolean recibe(float cantidad){
        return modificarSaldo(cantidad);
    }
    
    boolean moverACasilla(int numCasilla){
        casillaActual = numCasilla;
        puedeComprar = false;
        Diario.getInstance().ocurreEvento("Jugador "+this.nombre+" mueve casilla "+numCasilla);
        return true;
    }
    
    private boolean puedoGastar(float precio){
        return saldo>=precio;
    }
    
    boolean tieneAlgoQueGestionar(){
        return propiedades.size()>0;
    }
    
    boolean pasaPorSalida(){
        recibe(PasoPorSalida);
        Diario.getInstance().ocurreEvento("EL jugador "+this.nombre+" pasa por salida");
        return true;
    }
    
    @Override
    public int compareTo(Jugador otro){
        return Float.compare(saldo, otro.saldo); //0 si es igual, neg si 1<2, positivo si 2<1
    }
    
    int cantidadCasasHoteles(){
        int casasHoteles = 0;
        for(int i=0; i<propiedades.size();i++){
            casasHoteles += propiedades.get(i).cantidadCasasHoteles();
        }
        return casasHoteles;
    }
    
    boolean enBancaRota(){
        return saldo <= 0;
    }
    
    boolean getPuedeComprar(){
        return puedeComprar;
    }

    private boolean puedoEdificarCasa(CasillaCalle propiedad) {
        if (puedoGastar(propiedad.getPrecioEdificar()) && propiedad.getNumCasas()<getCasasMax()) {
            return true;
        }
        return false;
    }

    private boolean puedoEdificarHotel(CasillaCalle propiedad) {
        //return puedoGastar(propiedad.getPrecioEdificar());
        if(puedoGastar(propiedad.getPrecioEdificar())){
            if(propiedad.getNumHoteles()<getHotelesMax() && propiedad.getNumCasas()>=getCasasPorHotel())
                return true;
        }
        return false;
    }

    protected static int getCasasMax() { //Cambio visibilidad
        return CasasMax;
    }

    static int getCasasPorHotel() {
        return CasasPorHotel;
    }

    public int getCasillaActual() { //Cambio visibilidad
        return casillaActual;
    }

    protected static int getHotelesMax() { //CambioVisibilidad
        return HotelesMax;
    }

    public String getNombre() { //Cambio visibilidad
        return nombre;
    }

    private static float getPasoPorSalida() {
        return PasoPorSalida;
    }

    boolean isPuedeComprar() {
        return puedeComprar;
    }

    public float getSaldo() { //Cambio visibilidad
        return saldo;
    }

    public ArrayList<CasillaCalle> getPropiedades() {
        return propiedades;
    }
    
    boolean comprar(CasillaCalle titulo){
        boolean result = false;
        float precio;
        if(puedeComprar){
            precio = titulo.getPrecioCompra();
            if(puedoGastar(precio)){
                result = titulo.comprar(this);
                propiedades.add(titulo);
                Diario.getInstance().ocurreEvento("El jugador" + this.nombre + "compra la propiedad" + titulo);
                puedeComprar = false;
            }else{
                Diario.getInstance().ocurreEvento("El jugador" + this.nombre+"No tiene saldo para comprar la propiedad"+titulo);
            }
        }
        return result;
    }
  
    boolean construirHotel(int ip){
        boolean result = false;
        if(existeLaPropiedad(ip)){
            CasillaCalle propiedad = propiedades.get(ip);
            if(puedoEdificarHotel(propiedad)){
                result = propiedad.construirHotel(this); //Se le pasa un jugador??
                propiedad.derruirCasas(CasasPorHotel, this);
                Diario.getInstance().ocurreEvento("El jugador "+nombre+" construye hotel en la propiedad "+ip);
            }
        }
        return result;
    }
    
    boolean construirCasa(int ip){
        boolean result = false;
        boolean puedoEdificar = false;
        if(existeLaPropiedad(ip)){
            CasillaCalle propiedad = propiedades.get(ip);
            puedoEdificar = puedoEdificarCasa(propiedad);
            if(puedoEdificar){
                result = propiedad.construirCasa(this);
                Diario.getInstance().ocurreEvento("El jugador "+nombre+" construye cas en la propiedad "+ip);
            }
        }
        return result;
    }
    
    
    
}
