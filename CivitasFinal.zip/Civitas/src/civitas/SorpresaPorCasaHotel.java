/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class SorpresaPorCasaHotel extends Sorpresa{
    
    public SorpresaPorCasaHotel(String texto, int valor){
        super(texto, valor);
    }
    
    @Override
    public void aplicarAJugador(int actual, ArrayList<Jugador> todos){
        informe(actual, todos);
        Jugador jugadorAct = todos.get(actual);
        jugadorAct.modificarSaldo(getValor()*jugadorAct.cantidadCasasHoteles());
    }
}
