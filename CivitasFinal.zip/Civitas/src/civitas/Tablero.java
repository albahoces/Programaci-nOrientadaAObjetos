/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class Tablero {
    private ArrayList<Casilla> casillas;
    private boolean porSalida;
    
    public Tablero(){ //Cambio visibilidad a public
        casillas = new ArrayList<Casilla>();
        Casilla c = new Casilla("Salida");
        casillas.add(c);
        porSalida = false;
    }
    
    private boolean correcto(int numCasilla){
        return numCasilla <= casillas.size();
    }
    
    boolean computarPasoPorSalida(){
        boolean pS = porSalida;
        porSalida = false;
        return pS;
    }
    
    public void añadeCasilla(Casilla casilla){ //Cambio visibilidad a public
        casillas.add(casilla);
    }
    
    public Casilla getCasilla(int numCasilla){ //Cambio visibilidad a public
        if(correcto(numCasilla))
            return casillas.get(numCasilla);
        else
            return null;
    }
    
    public int nuevaPosicion(int actual, int tirada){ //Cambio visibilidad a public
        int nueva_pos = actual + tirada;
        if(nueva_pos >=casillas.size()){
            nueva_pos = nueva_pos - casillas.size();
            porSalida = true;
        }
        return nueva_pos;
    }
    
    
    
}
