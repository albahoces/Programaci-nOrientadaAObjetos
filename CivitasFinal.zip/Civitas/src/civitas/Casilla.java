/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class Casilla {
    //private TipoCasilla tipo;
    private String nombre;
    private float precioCompra, precioEdificar, precioBaseAlquiler;
    private int numCasas, numHoteles;
    private static final float FACTORALQUILERCALLE = 1.0f;
    private static final float FACTORALQUILERCASA = 1.0f;
    private static final float FACTORALQUILERHOTEL = 4.0f;
    private MazoSorpresa mazo;
    private Jugador propietario;
    private Sorpresa sorpresa;
    
    private void init(){
        //tipo = null;
        nombre = "";
        precioCompra = 0;
        precioEdificar = 0;
        precioBaseAlquiler = 0;
        numCasas = 0;
        numHoteles = 0;
        propietario = null;
        mazo = new MazoSorpresa();
    }
    public Casilla(String n){
        init();
        //tipo = TipoCasilla.DESCANSO;
        nombre = n;
    }
    
    public Casilla(String titulo, float pC, float pE, float aB ){
        init();
        //tipo = TipoCasilla.CALLE;
        nombre = titulo;
        precioCompra = pC;
        precioEdificar = pE;
        precioBaseAlquiler = aB;
    }
    
    public Casilla(String nombre, MazoSorpresa mazo){
        init();
        //tipo = TipoCasilla.SORPRESA;
        this.nombre = nombre;
        this.mazo = mazo;
        
    }
    
    void informe(int iactual, ArrayList<Jugador> todos){
        Diario.getInstance().ocurreEvento("Jugador en casilla actual: "+todos.get(iactual));
    }
    
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(float precioCompra) {
        this.precioCompra = precioCompra;
    }

    public float getPrecioEdificar() {
        return precioEdificar;
    }

    public void setPrecioEdificar(float precioEdificar) {
        this.precioEdificar = precioEdificar;
    }

    public float getPrecioBaseAlquiler() {
        return precioBaseAlquiler;
    }

    public void setPrecioBaseAlquiler(float precioBaseAlquiler) {
        this.precioBaseAlquiler = precioBaseAlquiler;
    }

    public int getNumCasas() {
        return numCasas;
    }

    public void setNumCasas(int numCasas) {
        this.numCasas = numCasas;
    }

    public int getNumHoteles() {
        return numHoteles;
    }

    public void setNumHoteles(int numHoteles) {
        this.numHoteles = numHoteles;
    }
    
    public float getPrecioAlquilerCompleto(){
        float precioCompleto = precioBaseAlquiler*(FACTORALQUILERCASA+numCasas+numHoteles*FACTORALQUILERHOTEL);
        return precioCompleto;
    }

    public MazoSorpresa getMazo() {
        return mazo;
    }

    public void setMazo(MazoSorpresa mazo) {
        this.mazo = mazo;
    }

    public Jugador getPropietario() {
        return propietario;
    }

    public void setPropietario(Jugador propietario) {
        this.propietario = propietario;
    }

    public Sorpresa getSorpresa() {
        return sorpresa;
    }

    public void setSorpresa(Sorpresa sorpresa) {
        this.sorpresa = sorpresa;
    }
    
    
    public boolean tienePropietario(){
        return propietario != null;
    }
    
    public void tramitarAlquiler(Jugador jugador){
        if(tienePropietario() && !esEsteElPropietario(jugador)){
            jugador.pagaAlquiler(getPrecioAlquilerCompleto());
            propietario.recibe(getPrecioAlquilerCompleto());
        }   
    }
    
    boolean derruirCasas(int i, Jugador jugador){
        if(this.esEsteElPropietario(jugador) && numCasas >= i){
            numCasas -= i;
            return true;
        }
        return false;
    }
    
    public boolean esEsteElPropietario(Jugador jugador) {
        return propietario == jugador;
    }

    public boolean construirCasa(Jugador jugador) {
        jugador.paga(precioEdificar);
        numCasas++;
        return true;
    }

    public boolean construirHotel(Jugador jugador) { //Se modifica el metodo en a P3
        jugador.paga(precioEdificar);
        numHoteles++;
        return true;
    }

    public int cantidadCasasHoteles() {
        return numCasas+numHoteles;
    }
    
    @Override
    public String toString(){
        String estado = nombre.toString()+".Precios: Compra: "+precioCompra+", Edificar: "
                +precioEdificar+", Alquiler base: "+precioBaseAlquiler+", Casas: "+numCasas+", Hoteles: "+numHoteles;
        return estado;
    }

    void recibeJugador(int iactual, ArrayList<Jugador> todos) {
        //Casilla descanso
        informe(iactual, todos);
    }
    
    
    boolean comprar(Jugador jugador){
        propietario = jugador;
        propietario.paga(precioCompra);
        return true;
    }
    
    
}
