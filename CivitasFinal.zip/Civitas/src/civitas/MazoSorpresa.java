/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author albah
 */
public class MazoSorpresa {
    private ArrayList<Sorpresa> sorpresas;
    private boolean barajada;
    private int usadas;
    private boolean debug;
    
    void init(){
        sorpresas = new ArrayList<Sorpresa>();
        barajada = false;
        usadas = 0;
    }
    
    MazoSorpresa(boolean debug){
        this.init();
        this.debug = debug; 
        if(debug) Diario.getInstance().ocurreEvento("Modod debug activado");
    }
    
    MazoSorpresa(){
        this.init();
        debug = false;
    }
    
    void alMazo(Sorpresa s){
        if(!barajada) sorpresas.add(s);
    }
    
    Sorpresa siguiente(){
        if(!barajada || usadas == sorpresas.size() && !debug){
            barajada = true;
            usadas = 0;
        }
        usadas++;
        Sorpresa carta_usada = sorpresas.get(0);
        sorpresas.remove(0);
        sorpresas.add(carta_usada);
        Collections.shuffle(sorpresas); //Barajar el array
        return carta_usada; 
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }
    
    
   
}
