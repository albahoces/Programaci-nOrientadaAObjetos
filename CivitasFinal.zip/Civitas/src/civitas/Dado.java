/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.Random;

/**
 *
 * @author albah
 */
public class Dado {
    private Random random = new Random();
    private int ultimoResultado;
    private boolean debug;
    private static final Dado instance = new Dado();
    private final static int VALORDEBUG = 1;
    private final static int VALORESTADO = 6;
    
    private Dado(){
        ultimoResultado = 1;
        debug = false;     
    }
    
    public static Dado getInstance(){
        return instance;
    }
    
    public int tirar(){ //Cambio visibilidad a public
        int valor;
        if(debug)
            valor = 1;
        else
            valor = random.nextInt(6)+1; //Por si el valor es 0 le sumamos 1
        
        ultimoResultado = valor;
        return valor;
    }
    
    public int getUltimoResultado(){ //Cambio visibilidad a public
        return ultimoResultado;
    }
    
    
    public int quienEmpieza(int n){ //Cambio de visibilidad a publica
        return random.nextInt(n);
    }
    
    public void setDebug(boolean d){
        debug = d;
        Diario.getInstance().ocurreEvento("Se ha modificado el atributo debug");
    }
    
    
}
