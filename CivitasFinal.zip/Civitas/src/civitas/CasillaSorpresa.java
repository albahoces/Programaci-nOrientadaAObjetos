/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class CasillaSorpresa extends Casilla{
    
    public CasillaSorpresa(String nombre, MazoSorpresa mazo){
        super(nombre, mazo);
    }
    
    @Override
    void recibeJugador(int iactual, ArrayList<Jugador> todos){
        super.setSorpresa(super.getMazo().siguiente());
        informe(iactual,todos);
        super.getSorpresa().aplicarAJugador(iactual,todos);
    }
    
}
