/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public abstract class Sorpresa {
    private String texto;
    private int valor;
    //private TipoSorpresa tipo;
    private MazoSorpresa mazo;
    
    Sorpresa(String texto, int valor){
        this.texto = texto;
        this.valor = valor;
    }
    
    abstract void aplicarAJugador(int actual, ArrayList<Jugador> todos);
    
    
    public void informe(int actual, ArrayList<Jugador> todos){
        Diario.getInstance().ocurreEvento("Se esta aplicando una sorpresa al jugador "+todos.get(actual).getNombre());
    }
    
    @Override
    public String toString(){
        return texto;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public MazoSorpresa getMazo() {
        return mazo;
    }

    public void setMazo(MazoSorpresa mazo) {
        this.mazo = mazo;
    }
    
    
}   

