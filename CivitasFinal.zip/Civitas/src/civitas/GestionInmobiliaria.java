/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author albah
 */
public class GestionInmobiliaria {
    private OperacionInmobiliaria operacion;
    private int indicePropiedad;
    
    public GestionInmobiliaria(OperacionInmobiliaria op, int i){
        operacion = op;
        indicePropiedad = i;
    }

    public OperacionInmobiliaria getOperacion() {
        return operacion;
    }

    public int getIndicePropiedad() {
        return indicePropiedad;
    }
    
    
}
