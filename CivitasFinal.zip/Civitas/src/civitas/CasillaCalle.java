/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author albah
 */
public class CasillaCalle extends Casilla{
    
    public CasillaCalle(String titulo, float pC, float pE, float aB){
        super(titulo, pC, pE, aB);
    }
    
    @Override
    void recibeJugador(int iactual, ArrayList<Jugador> todos){
        informe(iactual, todos);
        Jugador jugador = todos.get(iactual);
        if(!tienePropietario()){
            jugador.puedeComprarCasilla();
        }else{
            tramitarAlquiler(jugador);
        }
    }
}
