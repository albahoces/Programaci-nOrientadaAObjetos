/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistaTextualCivitas;
import GUI.Vista;
import GUI.Vista;
import civitas.Casilla;
import civitas.CasillaCalle;
import civitas.CivitasJuego;
import civitas.Diario;
import civitas.OperacionJuego;
import controladorCivitas.Respuesta;
import civitas.OperacionInmobiliaria;
import civitas.Jugador;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author albah
 */
public class VistaTextual implements Vista{
    
    private static String separador = "=====================";
    private Scanner in;
    CivitasJuego juegoModel;
    private int iPropiedad;
    private int iGestion;

    public VistaTextual(CivitasJuego juegoModel) {
        in = new Scanner(System.in);
        this.juegoModel = juegoModel;
    }

    @Override
    public void pausa() {
        System.out.print("\nPulsa una tecla");
        in.nextLine();
    }

    int leeEntero(int max, String msg1, String msg2) {
        Boolean ok;
        String cadena;
        int numero = -1;
        do {
            System.out.print(msg1);
            cadena = in.nextLine();
            try {
                numero = Integer.parseInt(cadena);
                ok = true;
            } catch (NumberFormatException e) { // No se ha introducido un entero
                System.out.println(msg2);
                ok = false;
            }
            if (ok && (numero < 0 || numero >= max)) {
                System.out.println(msg2);
                ok = false;
            }
        } while (!ok);

        return numero;
    }

    int menu(String titulo, ArrayList<String> lista) {
        String tab = "  ";
        int opcion;
        System.out.println(titulo);
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(tab + i + "-" + lista.get(i));
        }

        opcion = leeEntero(lista.size(),
                "\n" + tab + "Elige una opción: ",
                tab + "Valor erróneo");
        return opcion;
    }

    @Override
    public void actualiza() {
        System.out.println("Jugador Actual: "+juegoModel.getJugadorActual().toString());
        ArrayList<CasillaCalle> propiedades = juegoModel.getJugadorActual().getPropiedades();
        for(CasillaCalle c : propiedades){
            System.out.println("/n"+c.toString());
        }
        if(juegoModel.finalDelJuego()){
            ArrayList<Jugador> ranking = juegoModel.ranking();
            for (Jugador j : ranking) {
                System.out.println("/n" + j.toString());
            }
        }
    }
    
    @Override
    public Respuesta comprar(){
        ArrayList<String> respuesta=new ArrayList<String>();
        respuesta.add("SI");
        respuesta.add("NO");
        int opcion = menu("¿Desea comprar la calle a la que se ha llegado?",respuesta);
        return Respuesta.values()[opcion];
    }
    
    @Override
    public OperacionInmobiliaria elegirOperacion(){
        ArrayList<String> operacion=new ArrayList<String>();
        operacion.add("Construir Casa");
        operacion.add("Construir Hotel");
        operacion.add("Terminar");
        int opcion = menu("¿Desea comprar la calle a la que se ha llegado?",operacion);
        return OperacionInmobiliaria.values()[opcion];
    }
    
    @Override
    public int elegirPropiedad(){
        ArrayList<String> propiedadesString=new ArrayList<String>();
        ArrayList<CasillaCalle> propiedades = juegoModel.getJugadorActual().getPropiedades();
        for(CasillaCalle c : propiedades){
            propiedadesString.add(c.toString());
        }
        iPropiedad = menu("Elige un indice de la propiedad que desea realizar la gestion.\nNum propiedades: "+propiedadesString.size(),propiedadesString);
        return iPropiedad;
    }
    
    @Override
    public void mostrarSiguienteOperacion(OperacionJuego operacion){
        System.out.println(operacion); 
    }
    
    @Override
    public void mostrarEventos(){
        /*
        ArrayList<String> eventos;
        while(Diario.getInstance().eventosPendientes()){
            eventos = Diario.getInstance().getEventos();
            for(String s : eventos){
                System.out.println(s);
            }
        }
        */
        while (Diario.getInstance().eventosPendientes()){
          System.out.println(Diario.getInstance().leerEvento());
      }
    }
    
    public void mostrarEstado(){
        
        if(juegoModel.finalDelJuego()){
            ArrayList<Jugador> ranking = juegoModel.ranking();
            for (Jugador j : ranking) {
                System.out.println("/n" + j.toString());
            }
        }else{
            System.out.println("Jugador Actual: "+juegoModel.getJugadorActual().toString()); 
            //Aqui muestra tambien la casilla en la que está el jugador
        }
    }
    
}
