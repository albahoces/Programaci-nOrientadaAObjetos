/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladorCivitas;

import GUI.CivitasView;
import civitas.CivitasJuego;
import civitas.GestionInmobiliaria;
import civitas.OperacionInmobiliaria;
import civitas.OperacionJuego;
import vistaTextualCivitas.VistaTextual;

/**
 *
 * @author albah
 */
public class Controlador {
    private CivitasJuego juegoModel;
    //private VistaTextual vista;
    private CivitasView vista;
    
    public Controlador(CivitasJuego juego, CivitasView v){ //He cambiado su visibilidad a publica para poder usarlo en JuegoTexto
        juegoModel = juego;
        vista = v;
    }
    
    public void juega(){
        boolean finDelJuego = juegoModel.finalDelJuego();
        OperacionJuego op;
        int iPropiedad=-1;
        while(!finDelJuego){
            vista.actualiza();
            vista.pausa();
            op = juegoModel.siguientePaso();
            vista.mostrarSiguienteOperacion(op); 
            if(op!=OperacionJuego.PASAR_TURNO){
                vista.mostrarEventos();
            }
            finDelJuego = juegoModel.finalDelJuego();
            if(!finDelJuego){
                switch(op){
                    case COMPRAR:
                        Respuesta r = vista.comprar();
                        if(r == Respuesta.SI){
                            juegoModel.comprar();
                            juegoModel.siguientePasoCompletado(op);
                        }
                    break;
                    
                    case GESTIONAR:
                        OperacionInmobiliaria opI = vista.elegirOperacion();
                        if(opI != OperacionInmobiliaria.TERMINAR){
                            iPropiedad = vista.elegirPropiedad();
                        }
                        GestionInmobiliaria gestion = new GestionInmobiliaria(opI,iPropiedad);
                        switch (opI) {
                            case TERMINAR:
                                juegoModel.siguientePasoCompletado(op);
                                break;
                            case CONSTRUIR_CASA:
                                juegoModel.cosntruirCasa(iPropiedad);
                                break;
                            case CONSTRUIR_HOTEL:
                                juegoModel.cosntruirHotel(iPropiedad);
                                break;
                        }
                    break;
                    
                }
            }
            
        }
        vista.actualiza(); //Ya se calcula dentro el ranking
    }
    
    
}
